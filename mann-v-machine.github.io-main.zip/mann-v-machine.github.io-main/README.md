# simple-portfolio
a simple portfolio template.
# Preview
<img src="https://cdn.discordapp.com/attachments/854378301303947317/975341933964705802/Web_capture_15-5-2022_171911_127.0.0.1.jpeg">
